// app/api/users/route.ts
import { NextResponse } from "next/server";
import { requireRole } from "@/lib/auth";
import { supabaseAdmin } from "@/lib/supabaseClient";
import type { ApiResponse, CreateUserRequest, User } from "@/types/api";

// Get all users (superadmin only)
export async function GET(req: Request) {
  try {
    const { data, error } = await supabaseAdmin
      .from("profiles")
      .select("id, name, email, role, created_at");

    if (error) {
      throw new Error(error.message);
    }

    return NextResponse.json<ApiResponse<User[]>>(
      {
        success: true,
        data: data as User[],
        message: "Users retrieved successfully",
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json<ApiResponse>(
      {
        success: false,
        error: error.message || "Failed to get users",
      },
      { status: error.message.includes("Unauthorized") ? 403 : 500 }
    );
  }
}
