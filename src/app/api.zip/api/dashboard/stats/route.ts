// app/api/dashboard/stats/route.ts
import { NextResponse } from "next/server"
import { getUserFromRequest } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabaseAdmin"
import type { ApiResponse } from "@/types/api"

export async function GET(req: Request) {
  try {
    // Get authenticated user
    const user = await getUserFromRequest(req)

    // Get item statistics
    const { data: items, error: itemsError } = await supabaseAdmin.from("items").select("id, status, borrowed_by")

    if (itemsError) {
      throw new Error(itemsError.message)
    }

    // Calculate statistics
    const stats = {
      totalItems: items.length,
      availableItems: items.filter((item) => item.status === "tersedia").length,
      borrowedItems: items.filter((item) => item.status === "dipinjam").length,
      pendingItems: items.filter((item) => item.status === "pending").length,
    }

    // For students, add personal stats
    if (user.role === "siswa") {
      stats["myBorrowedItems"] = items.filter(
        (item) => item.status === "dipinjam" && item.borrowed_by === user.id,
      ).length

      // Get pending requests
      const { data: pendingLoans, error: loansError } = await supabaseAdmin
        .from("loans")
        .select("id")
        .eq("student_id", user.id)
        .eq("status", "pending")

      if (loansError) {
        throw new Error(loansError.message)
      }

      stats["myPendingRequests"] = pendingLoans.length
    }

    // For admins, add user statistics
    if (user.role === "admin" || user.role === "superadmin") {
      const { data: users, error: usersError } = await supabaseAdmin.from("profiles").select("id, role")

      if (usersError) {
        throw new Error(usersError.message)
      }

      stats["totalUsers"] = users.length
      stats["studentUsers"] = users.filter((u) => u.role === "siswa").length
      stats["adminUsers"] = users.filter((u) => u.role === "admin" || u.role === "superadmin").length
    }

    return NextResponse.json<ApiResponse>(
      {
        success: true,
        data: stats,
        message: "Dashboard statistics retrieved successfully",
      },
      { status: 200 },
    )
  } catch (error: any) {
    return NextResponse.json<ApiResponse>(
      {
        success: false,
        error: error.message || "Failed to get dashboard statistics",
      },
      { status: error.message.includes("Unauthorized") ? 401 : 500 },
    )
  }
}
