// app/api/loans/route.ts
import { NextResponse } from "next/server"
import { getUserFromRequest } from "@/lib/auth"
import { supabaseAdmin } from "@/lib/supabaseAdmin"
import type { ApiResponse, Loan } from "@/types/api"

export async function GET(req: Request) {
  try {
    // Get authenticated user
    const user = await getUserFromRequest(req)

    // Parse query parameters
    const url = new URL(req.url)
    const status = url.searchParams.get("status")
    const validStatuses = ["pending", "approved", "rejected", "returned"]

    let query = supabaseAdmin.from("loans").select(`
        id, 
        item_id, 
        student_id, 
        status, 
        requested_at, 
        approved_at, 
        approved_by, 
        rejected_at, 
        rejected_by, 
        rejection_notice, 
        returned_at, 
        return_note,
        items:item_id (name, code, image)
      `)

    // Filter by status if provided
    if (status && validStatuses.includes(status)) {
      query = query.eq("status", status)
    }

    // Students can only see their own loans
    if (user.role === "siswa") {
      query = query.eq("student_id", user.id)
    }

    const { data, error } = await query.order("requested_at", { ascending: false })

    if (error) {
      throw new Error(error.message)
    }

    return NextResponse.json<ApiResponse<Loan[]>>(
      {
        success: true,
        data: data as Loan[],
        message: "Loans retrieved successfully",
      },
      { status: 200 },
    )
  } catch (error: any) {
    return NextResponse.json<ApiResponse>(
      {
        success: false,
        error: error.message || "Failed to get loans",
      },
      { status: error.message.includes("Unauthorized") ? 401 : 500 },
    )
  }
}
